#pragma once

#include "settings.hpp"
#include "synths.hpp"

#include <drogon/drogon.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_core/juce_core.h>

#include <exception>
#include <iostream>


#define assert_res(cond)                                        \
	do {                                                        \
		bool result = bool(cond);                               \
		if (!result) {                                          \
			return juce::Result::fail("assert failed: " #cond); \
		}                                                       \
	} while (0)

juce::Result getDuration(double& durationOut, const juce::String& durationType, juce::XmlElement* chord_or_rest)
{
	if (durationType == "quarter") {
		durationOut = 1.0;
	} else if (durationType == "whole") {
		durationOut = 4.0;
	} else if (durationType == "half") {
		durationOut = 2.0;
	} else if (durationType == "eighth") {
		durationOut = 0.5;
	} else if (durationType == "16th") {
		durationOut = 0.25;
	} else if (durationType == "32nd") {
		durationOut = 0.125;
	} else if (durationType == "64th") {
		durationOut = 0.0625;
	} else if (durationType == "measure") {
		assert_res(chord_or_rest->getTagName() == "Rest");
		auto dur = chord_or_rest->getChildElementAllSubText("duration", "4/4");
		auto idx = dur.indexOf("/");
		if (idx == -1) {
			return juce::Result::fail("unknown duration: " + dur);
		}
		auto num = dur.substring(0, idx).getIntValue();
		auto den = dur.substring(idx + 1).getIntValue();
		assert_res(num > 0 && num <= 16);
		assert_res(den > 0 && den <= 16);
		durationOut = 4.0 / den * num;
		assert_res(durationOut <= 4.0);
	} else {
		return juce::Result::fail("unknown duration type: " + durationType);
	}
	return juce::Result::ok();
}

class Chord
{
public:
	std::vector<int> pitches; // Pitches (0-127).

	Chord(const juce::XmlElement* chord)
	{
		for (auto note : chord->getChildWithTagNameIterator("Note")) {
			auto pitch = note->getChildElementAllSubText("pitch", "?").getIntValue();
			if (pitch > 0)
				pitches.push_back(pitch);
		}
	}

	bool isValid() const
	{
		return !pitches.empty();
	}
};

/**
 * Jank class representation of a MuseScore staff.
 */
class Staff
{
public:
	const juce::XmlElement* staff;

	Staff(const juce::XmlElement* xml) : staff{xml} {}

	int getNumMeasures() const
	{
		int measureCount = 0;
		for (auto mm : staff->getChildWithTagNameIterator("Measure")) {
			(void)mm;
			measureCount++;
		}
		return measureCount;
	}

	/**
	 * Extract MIDI events (noteOn, noteOff) to a midi buffer, along with the number of samples
	 * in the entire staff.
	 */
	juce::Result toMidiBuffer(juce::MidiBuffer& midiBuffer, int& numSamples, double sampleRate) const
	{
		int bpm = parseTempo();
		double samplesPerBeat = sampleRate / (bpm / 60.0); // sample/s `div` beats/s

		double currSample = 0; // Current sample.
		numSamples = 0;

		for (auto mm : staff->getChildWithTagNameIterator("Measure")) {
			if (auto vc = mm->getChildByName("voice")) {
				for (auto obj : vc->getChildIterator()) {
					auto tag = obj->getTagName();

					if (auto durationType = obj->getChildByName("durationType")) {
						double multiplier;
						auto res = getDuration(multiplier, durationType->getAllSubText(), obj);
						if (!res)
							return res;

						if (obj->getTagName() == "Chord") {
							Chord chord{obj};
							if (!chord.isValid())
								return juce::Result::fail("invalid chord");

							if (auto dots = obj->getChildByName("dots"); dots) {
								int ndots = dots->getAllSubText().getIntValue();
								switch (ndots) {
									case 1: multiplier *= 1.5; break;
									case 2: multiplier *= 1.5 * 1.5; break;
									case 3: multiplier *= 1.5 * 1.5 * 1.5; break;
									default: break;
								}
							}

							// TODO: implement ties.

							float vel = JUCE_INITIAL_VELOCITY;


							for (auto pitch : chord.pitches) {
								midiBuffer.addEvent(juce::MidiMessage::noteOn(1, pitch, vel),
													static_cast<int>(currSample));
								midiBuffer.addEvent(
									juce::MidiMessage::noteOff(1, pitch, vel),
									static_cast<int>(currSample + samplesPerBeat * multiplier * JUCE_NOTE_DURATION));
							}
						} else if (obj->getTagName() == "Rest") {
							// Pass. No rest for the ~~wicked~~ CTF player.
						}

						double nextSample = currSample + samplesPerBeat * multiplier;
						currSample = nextSample;
						numSamples = static_cast<int>(ceil(currSample));
					} else {
						if (obj->getTagName() == "Dynamic") {
							// Pass. Baroque composers would approve.
						}
					}
				}
			}
		}
		return juce::Result::ok();
	}

private:
	int parseTempo() const
	{
		if (auto mm = staff->getChildByName("Measure"); !mm)
			goto fail;
		else if (auto vc = mm->getChildByName("voice"); !vc)
			goto fail;
		else if (auto tempo = vc->getChildByName("Tempo"); !tempo)
			goto fail;
		else if (auto text = tempo->getChildByName("text"); !text)
			goto fail;
		else {
			auto content = text->getAllSubText();
			auto idx = content.indexOf(" = ");
			if (idx == -1)
				goto fail;

			auto bpm = content.substring(idx + 3).getIntValue();
			if (bpm >= 40 && bpm <= 200) {
				return bpm;
			}
		}

	fail:
		return JUCE_DEFAULT_BPM;
	}
};

class Score
{
public:
	std::vector<Staff> staves;
	Score(const std::vector<Staff>& _staves) : staves{_staves} {}

	// TODO: change to {std,tl}::expected.
	static std::optional<Score> parseFrom(const std::unique_ptr<juce::XmlElement>& msRoot)
	{
		if (auto score = msRoot->getChildByName("Score"); !score) {
			return std::nullopt;
		} else {
			std::vector<Staff> staves;
			for (auto* staff : score->getChildWithTagNameIterator("Staff")) {
				staves.push_back(Staff(staff));
			}
			return {Score(staves)};
		}
	}
};

void makeSynth(juce::Synthesiser& synth, double sampleRate)
{
	synth.addSound(new SineWaveSound());
	synth.setCurrentPlaybackSampleRate(sampleRate);

	for (int i = 0; i < 4; i++)
		synth.addVoice(new WavetableVoice(JUCE_WAVETABLE, JUCE_WAVETABLE_SIZE));
}

juce::Result checkMuseScoreFile(const juce::ZipFile& mscz)
{
	assert_res(mscz.getNumEntries() > 0);
	for (int i = 0; i < mscz.getNumEntries(); i++) {
		// No slippies.
		auto filename = mscz.getEntry(i)->filename;
		assert_res(!filename.contains(".."));
	}
	return juce::Result::ok();
}

juce::Result unzipMusescoreFile(juce::File& mscx, const std::string& musescorePath)
{
	// MuseScore XML.
	juce::File msFile(musescorePath);
	assert_res(msFile.existsAsFile());

	juce::File unzipDirectory = msFile.getParentDirectory().getChildFile("tmp");
	unzipDirectory.createDirectory();

	juce::ZipFile mscz(msFile);
	if (auto res = checkMuseScoreFile(mscz); !res)
		return res;

	for (int i = 0; i < mscz.getNumEntries(); i++) {
		juce::String fn = mscz.getEntry(i)->filename;

		for (char c : fn) {
			if (!(isalpha(c) || c == '/' || c == '.' || c == '-' || c == '_'))
				return juce::Result::fail("invalid filename");
		}
	}

	if (auto res = mscz.uncompressTo(unzipDirectory, false); !res)
		return res;

	// Find mscx file.
	for (int i = 0; i < mscz.getNumEntries(); i++) {
		juce::File file = unzipDirectory.getChildFile(mscz.getEntry(i)->filename);
		if (file.existsAsFile()) {
			if (file.getFileExtension() == ".mscx") {
				mscx = file;
			}
		}
	}

	if (mscx == juce::File())
		return juce::Result::fail("mscz does not contain mscx");

	return juce::Result::ok();
}

juce::Result synthesise(const std::string& musescorePath, const std::string& outputPath)
{
	juce::File mscx;
	if (auto res = unzipMusescoreFile(mscx, musescorePath); !res)
		return res;

	juce::File musicOutputFile(outputPath);
	if (musicOutputFile.existsAsFile()) {
		// The Juce audio writer doesn't seem to overwrite existing files
		// properly. So we'll do it for them!
		musicOutputFile.deleteFile();
	}

	juce::WavAudioFormat fmt;
	juce::AudioChannelSet channelSet;
	channelSet = juce::AudioChannelSet::stereo();
	assert_res(fmt.isChannelLayoutSupported(channelSet));

	auto sampleRate = 42100;

	auto ofs = new juce::FileOutputStream(musicOutputFile);
	auto writer = std::unique_ptr<juce::AudioFormatWriter>{fmt.createWriterFor(ofs, sampleRate, channelSet, 16, {}, 0)};
	if (!writer)
		return juce::Result::fail("failed to construct an audio writer");

	auto xml = juce::parseXML(mscx);
	if (!xml)
		return juce::Result::fail("failed to parse xml"); // Xcuse Me Laddie, please provide a proper MuseScore 4 file.

	auto maybe_score = Score::parseFrom(xml);
	if (!maybe_score)
		return juce::Result::fail("failed to parse score");

	auto score = *maybe_score;
	if (score.staves.empty())
		return juce::Result::fail("no staves found");

	// Keep it simple - just use the first staff.
	auto staff = score.staves[0];

	int numMeasures = staff.getNumMeasures();
	if (numMeasures > JUCE_MAX_MEASURE_COUNT)
		return juce::Result::fail("too many measures");

	juce::MidiBuffer midiBuffer;
	int totalSamples;
	if (auto res = staff.toMidiBuffer(midiBuffer, totalSamples, sampleRate); !res)
		return res;

	juce::AudioSampleBuffer buffer(2, JUCE_MAX_BUFFER_SIZE);
	if (totalSamples > JUCE_MAX_SECONDS * sampleRate)
		return juce::Result::fail("audio exceeded max duration");
	// What? You thought you could just upload Wagner's Ring Cycle and watch the server burn?)

	int samplesProcessed = JUCE_MAX_BUFFER_SIZE;

	juce::Synthesiser synth;
	makeSynth(synth, sampleRate);

	int samplesToProcess = JUCE_MAX_BUFFER_SIZE;
	int startSample = 0;
	for (int readerStartSample = 0; readerStartSample < totalSamples; readerStartSample += samplesProcessed) {
		if (totalSamples - readerStartSample < samplesProcessed) {
			samplesProcessed = totalSamples - readerStartSample;
		}

		buffer.clear();

		juce::MidiBuffer localisedMidiBuffer;
		localisedMidiBuffer.addEvents(midiBuffer, startSample, samplesToProcess, -startSample);
		startSample += samplesToProcess;

		synth.renderNextBlock(buffer, localisedMidiBuffer, 0, samplesToProcess);
		writer->writeFromAudioSampleBuffer(buffer, 0, samplesToProcess);
	}
	return juce::Result::ok();
}
